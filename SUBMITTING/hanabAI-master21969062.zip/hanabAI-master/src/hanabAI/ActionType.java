package hanabAI;
/**
 * An enumeration of the different types of actions a player can do in the game Hanabi.
 **/ 
public enum ActionType{PLAY,DISCARD,HINT_COLOUR,HINT_VALUE};


